use crossterm::event::{self, Event, KeyCode, MouseEventKind};
use crossterm::terminal::{disable_raw_mode, enable_raw_mode};
use std::time::Duration;
fn main() -> std::io::Result<()> {
    enable_raw_mode()?;
    let (mut moves, mut keys, mut other) = (0u32, 0u32, 0u32);
    let mut last = (0, 0);
    loop {
        if event::poll(Duration::from_millis(50))? {
            match event::read()? {
                Event::Mouse(m) if m.kind == MouseEventKind::Moved => { moves += 1; last = (m.column, m.row); }
                Event::Key(k) => { keys += 1; if k.code == KeyCode::Char('q') { break; } }
                _ => other += 1,
            }
        }
    }
    disable_raw_mode()?;
    std::fs::write(std::env::var("OUT").unwrap(), format!("moves={moves} keys={keys} other={other} last={last:?}\n"))?;
    Ok(())
}
