use std::io::Write as _;
use std::time::Duration;
use termina::escape::csi::{self};
use termina::event::{KeyCode, MouseEventKind};
use termina::{Event, PlatformTerminal, Terminal};

macro_rules! decset {
    ($mode:ident) => {
        csi::Csi::Mode(csi::Mode::SetDecPrivateMode(csi::DecPrivateMode::Code(csi::DecPrivateModeCode::$mode)))
    };
}

fn main() -> std::io::Result<()> {
    let mut terminal = PlatformTerminal::new()?;
    terminal.enter_raw_mode()?;
    write!(terminal, "{}{}{}{}", decset!(MouseTracking), decset!(ButtonEventMouse), decset!(AnyEventMouse), decset!(SGRMouse))?;
    terminal.flush()?;
    let (mut moves, mut keys, mut other) = (0u32, 0u32, 0u32);
    let mut last = (0, 0);
    loop {
        if terminal.poll(|e| !e.is_escape(), Some(Duration::from_millis(50)))? {
            match terminal.read(|e| !e.is_escape())? {
                Event::Mouse(m) if matches!(m.kind, MouseEventKind::Moved) => { moves += 1; last = (m.column, m.row); }
                Event::Key(k) => { keys += 1; if k.code == KeyCode::Char('q') { break; } }
                _ => other += 1,
            }
        }
    }
    drop(terminal);
    std::fs::write(std::env::var("OUT").unwrap(), format!("moves={moves} keys={keys} other={other} last={last:?}\n"))?;
    Ok(())
}
