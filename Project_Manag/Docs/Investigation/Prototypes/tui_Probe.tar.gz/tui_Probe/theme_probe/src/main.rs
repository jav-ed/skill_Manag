use std::time::{Duration, Instant};
use terminal_colorsaurus::{theme_mode, QueryOptions};
fn main() {
    let ms: u64 = std::env::var("TIMEOUT_MS").ok().and_then(|v| v.parse().ok()).unwrap_or(1000);
    let t = Instant::now();
    let mut o = QueryOptions::default();
    o.timeout = Duration::from_millis(ms);
    let r = theme_mode(o);
    let line = format!("RESULT {:?} in {:?}\n", r, t.elapsed());
    std::fs::write(std::env::var("OUT").unwrap(), line).unwrap();
}
