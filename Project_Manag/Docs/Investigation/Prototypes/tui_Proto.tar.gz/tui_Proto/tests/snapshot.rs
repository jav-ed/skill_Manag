mod common;
use common::*;
use proto::app::Screen;

#[test]
fn list_screen_80x24() {
    let mut app = list_app(400);
    let mut t = term(80, 24);
    draw(&mut t, &mut app);
    insta::assert_snapshot!(t.backend());
}

#[test]
fn list_screen_narrow_40x12_with_wide_glyphs() {
    let mut app = list_app(400);
    app.view.offset = 5; // rows 7 and 8 hold CJK and emoji names
    app.view.cursor = 5;
    let mut t = term(40, 12);
    draw(&mut t, &mut app);
    insta::assert_snapshot!(t.backend());
}

#[test]
fn menu_screen() {
    let mut app = list_app(10);
    app.screen = Screen::Menu;
    let mut t = term(60, 14);
    draw(&mut t, &mut app);
    insta::assert_snapshot!(t.backend());
}

#[test]
fn help_overlay() {
    let mut app = list_app(30);
    app.show_help = true;
    let mut t = term(60, 16);
    draw(&mut t, &mut app);
    insta::assert_snapshot!(t.backend());
}

#[test]
fn filter_active() {
    let mut app = list_app(400);
    app.handle(key(proto::input::Code::Char('/')));
    for c in "skl01".chars() {
        app.handle(key(proto::input::Code::Char(c)));
    }
    let mut t = term(70, 14);
    draw(&mut t, &mut app);
    insta::assert_snapshot!(t.backend());
}
