mod common;
use common::term;
use proto::hit::Target;
use proto::input::{Button, Code, Key, Mouse, MouseKind};
use proto::picker::{Outcome, Picker};

fn tree(tag: &str) -> std::path::PathBuf {
    let root = std::env::temp_dir().join(format!("picker-test-{tag}-{}", std::process::id()));
    let _ = std::fs::remove_dir_all(&root);
    for d in ["alpha/inner", "beta", ".hidden", "Gamma"] {
        std::fs::create_dir_all(root.join(d)).unwrap();
    }
    std::fs::write(root.join("file.txt"), "x").unwrap();
    root
}

fn click(p: &mut Picker, t: Target) -> Outcome {
    let r = p.hits().rect_of(t).expect("target");
    p.on_mouse(&Mouse { kind: MouseKind::Down(Button::Left), column: r.x + 1, row: r.y })
}

#[test]
fn lists_only_visible_dirs_sorted_and_navigates_by_mouse_and_keys() {
    let root = tree("nav");
    let mut p = Picker::new(&root).unwrap();
    let mut t = term(60, 12);
    t.draw(|f| p.draw(f, f.area())).unwrap();
    assert_eq!(p.dirs, ["alpha", "beta", "Gamma"], "files and hidden dirs are not listed");
    // the first line holds the temp path (varies per run), so snapshot the body only
    let body: Vec<String> = t.backend().to_string().lines().skip(1).map(str::to_owned).collect();
    insta::assert_snapshot!(body.join("\n"));

    click(&mut p, Target::PickerRow(1)); // first click moves the cursor to beta
    assert_eq!((p.cursor, p.cwd.clone()), (1, root.clone()));
    click(&mut p, Target::PickerRow(1)); // click on the selected row opens it
    assert!(p.cwd.ends_with("beta"));
    t.draw(|f| p.draw(f, f.area())).unwrap(); // hit map must be rebuilt after the directory changed
    click(&mut p, Target::PickerUp);
    assert_eq!(p.cwd, root);
    t.draw(|f| p.draw(f, f.area())).unwrap();
    click(&mut p, Target::PickerRow(0));
    assert!(p.cwd.ends_with("alpha"));
    t.draw(|f| p.draw(f, f.area())).unwrap();
    assert_eq!(p.dirs, ["inner"]);

    click(&mut p, Target::PickerUp);
    assert_eq!(p.cwd, root);
    p.on_key(&Key::press(Code::Char('.')));
    assert!(p.dirs.contains(&".hidden".to_string()));
    p.on_key(&Key::press(Code::Down));
    p.on_key(&Key::press(Code::Right)); // open second entry
    t.draw(|f| p.draw(f, f.area())).unwrap();
    match click(&mut p, Target::PickerSelect) {
        Outcome::Chosen(path) => assert!(path.starts_with(&root) && path != root),
        Outcome::Pending => panic!("select button did nothing"),
    }
    std::fs::remove_dir_all(&root).unwrap();
}

#[test]
fn unreadable_directory_is_a_visible_error_not_a_silent_skip() {
    let root = tree("denied");
    let denied = root.join("beta");
    use std::os::unix::fs::PermissionsExt;
    std::fs::set_permissions(&denied, std::fs::Permissions::from_mode(0o000)).unwrap();
    let mut p = Picker::new(&root).unwrap();
    p.on_key(&Key::press(Code::Down)); // beta
    p.on_key(&Key::press(Code::Right));
    let mut t = term(70, 8);
    t.draw(|f| p.draw(f, f.area())).unwrap();
    assert!(p.error.is_some() && p.cwd == root, "stayed in place and kept the error");
    assert!(t.backend().to_string().contains("error:"));
    std::fs::set_permissions(&denied, std::fs::Permissions::from_mode(0o755)).unwrap();
    std::fs::remove_dir_all(&root).unwrap();
}
