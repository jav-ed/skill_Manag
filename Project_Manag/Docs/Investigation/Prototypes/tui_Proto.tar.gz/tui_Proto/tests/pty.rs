//! End-to-end through a real pseudo terminal: portable-pty drives the binary, vt100 emulates the screen.
use portable_pty::{native_pty_system, Child, CommandBuilder, MasterPty, PtySize};
use std::io::{Read, Write};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

struct Session {
    master: Box<dyn MasterPty + Send>,
    writer: Box<dyn Write + Send>,
    child: Box<dyn Child + Send + Sync>,
    screen: Arc<Mutex<vt100::Parser>>,
    raw: Arc<Mutex<Vec<u8>>>,
}

impl Drop for Session {
    fn drop(&mut self) {
        let _ = self.child.kill();
    }
}

impl Session {
    fn spawn(rows: u16, cols: u16) -> Self {
        Self::spawn_env(rows, cols, &[])
    }

    fn spawn_env(rows: u16, cols: u16, env: &[(&str, &str)]) -> Self {
        let pair = native_pty_system().openpty(PtySize { rows, cols, pixel_width: 0, pixel_height: 0 }).unwrap();
        let mut cmd = CommandBuilder::new(env!("CARGO_BIN_EXE_proto"));
        cmd.env("TERM", "xterm-256color");
        for (k, v) in env {
            cmd.env(k, v);
        }
        let child = pair.slave.spawn_command(cmd).unwrap();
        drop(pair.slave);
        let mut reader = pair.master.try_clone_reader().unwrap();
        let writer = pair.master.take_writer().unwrap();
        let screen = Arc::new(Mutex::new(vt100::Parser::new(rows, cols, 0)));
        let raw = Arc::new(Mutex::new(Vec::new()));
        let (s, r) = (screen.clone(), raw.clone());
        thread::spawn(move || {
            let mut buf = [0u8; 8192];
            while let Ok(n) = reader.read(&mut buf) {
                if n == 0 {
                    break;
                }
                s.lock().unwrap().process(&buf[..n]);
                r.lock().unwrap().extend_from_slice(&buf[..n]);
            }
        });
        Self { master: pair.master, writer, child, screen, raw }
    }

    fn text(&self) -> String {
        self.screen.lock().unwrap().screen().contents()
    }

    fn wait_for(&self, needle: &str) {
        let end = Instant::now() + Duration::from_secs(5);
        while Instant::now() < end {
            if self.text().contains(needle) {
                return;
            }
            thread::sleep(Duration::from_millis(15));
        }
        panic!("timeout waiting for {needle:?}; screen:\n{}", self.text());
    }

    fn send(&mut self, s: &str) {
        self.writer.write_all(s.as_bytes()).unwrap();
        self.writer.flush().unwrap();
    }

    /// SGR mouse report: button code, 1-based column and row.
    fn mouse(&mut self, code: u8, col: u16, row: u16, press: bool) {
        self.send(&format!("\x1b[<{code};{col};{row}{}", if press { 'M' } else { 'm' }));
    }

    fn row(&self, r: u16) -> String {
        self.screen.lock().unwrap().screen().rows(0, 200).nth(r as usize).unwrap_or_default()
    }

    fn resize(&self, rows: u16, cols: u16) {
        self.master.resize(PtySize { rows, cols, pixel_width: 0, pixel_height: 0 }).unwrap();
        self.screen.lock().unwrap().screen_mut().set_size(rows, cols);
    }

    fn cpu_ticks(&self) -> u64 {
        let pid = self.child.process_id().unwrap();
        let stat = std::fs::read_to_string(format!("/proc/{pid}/stat")).unwrap();
        let rest = stat.rsplit(')').next().unwrap();
        let f: Vec<&str> = rest.split_whitespace().collect();
        f[11].parse::<u64>().unwrap() + f[12].parse::<u64>().unwrap()
    }
}

#[test]
fn full_session_menu_list_filter_mouse_resize_quit() {
    let mut s = Session::spawn(30, 100);
    s.wait_for("skill_Manag");
    s.send("\r"); // open List: scan runs on a worker thread, UI keeps painting the spinner
    s.wait_for("Scanning projects");
    s.wait_for("400 installed");

    s.send("/skl01");
    s.wait_for("72 matching");
    s.send("\x1b");
    s.wait_for("400 installed");

    // Screen row 4 (0-based) is the first item: header, title, filter, colhdr, items...
    assert!(s.row(4).starts_with("> [ ] skill-000"), "row4 = {:?}", s.row(4));
    s.mouse(0, 10, 8, true); // click 1-based row 8 = 0-based row 7 = item 3
    s.mouse(0, 10, 8, false);
    s.wait_for("1 / 400 selected");
    assert!(s.row(7).contains("[✓]"), "row7 = {:?}", s.row(7));

    s.mouse(35, 10, 10, true); // motion only (no button): hover row 9 -> item 5
    s.wait_for("rows 1");
    thread::sleep(Duration::from_millis(100));
    assert!(s.row(9).starts_with(">"), "hover did not move cursor: {:?}", s.row(9));

    for _ in 0..3 {
        s.mouse(65, 10, 10, true); // wheel down
    }
    s.wait_for("rows 10");

    s.resize(20, 60);
    thread::sleep(Duration::from_millis(300));
    let t = s.text();
    assert!(t.contains("of 400"), "after resize:\n{t}");
    assert_eq!(t.lines().count().min(20), t.lines().count().min(20));

    // idle: no animation running, so the process must not burn CPU
    let before = s.cpu_ticks();
    thread::sleep(Duration::from_secs(2));
    let idle = s.cpu_ticks() - before;
    assert!(idle <= 1, "idle cpu ticks over 2s: {idle}");

    s.send("q"); // back to menu
    s.wait_for("description line");
    s.send("q"); // quit
    let end = Instant::now() + Duration::from_secs(3);
    while s.child.try_wait().unwrap().is_none() {
        assert!(Instant::now() < end, "process did not exit");
        thread::sleep(Duration::from_millis(20));
    }
}

#[test]
fn osc8_link_and_mouse_modes_are_emitted() {
    let mut s = Session::spawn(24, 80);
    s.wait_for("skill_Manag");
    let raw = String::from_utf8_lossy(&s.raw.lock().unwrap()).to_string();
    assert!(raw.contains("\x1b]8;;https://example.com\x1b\\example.com\x1b]8;;\x1b\\"), "OSC 8 not emitted");
    assert!(raw.contains("\x1b[?1003h"), "any-motion mouse tracking not enabled");
    assert!(raw.contains("\x1b[?1049h"), "alt screen not entered");
    s.send("\x03"); // ctrl+c is a key event in raw mode
    let end = Instant::now() + Duration::from_secs(3);
    while s.child.try_wait().unwrap().is_none() {
        assert!(Instant::now() < end, "ctrl+c did not quit");
        thread::sleep(Duration::from_millis(20));
    }
    let raw = String::from_utf8_lossy(&s.raw.lock().unwrap()).to_string();
    assert!(raw.contains("\x1b[?1049l") && raw.contains("\x1b[?1003l"), "terminal state not restored");
}

#[test]
fn motion_flood_is_coalesced() {
    let stats = std::env::temp_dir().join(format!("proto-stats-{}", std::process::id()));
    let _ = std::fs::remove_file(&stats);
    let n: u32 = std::env::var("FLOOD").ok().and_then(|v| v.parse().ok()).unwrap_or(2000);
    let mut s = Session::spawn_env(30, 100, &[("PROTO_STATS_FILE", stats.to_str().unwrap())]);
    s.wait_for("skill_Manag");
    s.send("\r");
    s.wait_for("400 installed");
    let cpu0 = s.cpu_ticks();
    let t0 = Instant::now();
    let mut burst = String::new();
    for i in 0..n {
        burst.push_str(&format!("\x1b[<35;{};{}M", 5 + (i % 60), 5 + (i % 20)));
    }
    burst.push_str("\x1b[<35;10;12M");
    // Write from a thread so a stuck write cannot hang the test.
    let mut w = std::mem::replace(&mut s.writer, Box::new(std::io::sink()));
    let h = thread::spawn(move || {
        w.write_all(burst.as_bytes()).unwrap();
        w.flush().unwrap();
        w
    });
    thread::sleep(Duration::from_secs(3));
    let settled = t0.elapsed();
    if !h.is_finished() {
        // The kernel tty buffer is full because the child stopped reading its input.
        panic!("BACKEND STALL: writer still blocked after {settled:?}; the child stopped reading a {n}-event burst");
    }
    let final_ok = s.row(11).starts_with(">");
    s.writer = h.join().unwrap();
    println!("flood of {n} motion events: waited {settled:?}, final hover applied={final_ok}, child cpu ticks {}", s.cpu_ticks() - cpu0);
    s.send("\x03");
    let end = Instant::now() + Duration::from_secs(5);
    while s.child.try_wait().unwrap().is_none() && Instant::now() < end {
        thread::sleep(Duration::from_millis(20));
    }
    println!("{}", std::fs::read_to_string(&stats).unwrap_or_default());
    assert!(final_ok, "BACKEND STALL: the last mouse event of a {n}-event burst was never delivered");
}

#[test]
fn dump_screen_for_backend_comparison() {
    let Ok(out) = std::env::var("DUMP_TO") else { return };
    let mut s = Session::spawn(30, 100);
    s.wait_for("skill_Manag");
    s.send("\r");
    s.wait_for("400 installed");
    s.send("/skl07");
    s.wait_for("matching");
    thread::sleep(Duration::from_millis(200));
    let mut text = s.text();
    let attrs = {
        let p = s.screen.lock().unwrap();
        let sc = p.screen();
        let mut a = String::new();
        for r in 0..30u16 {
            for c in 0..100u16 {
                if let Some(cell) = sc.cell(r, c) {
                    if cell.bold() || cell.underline() {
                        a.push_str(&format!("({r},{c}) b={} u={} fg={:?}\n", cell.bold(), cell.underline(), cell.fgcolor()));
                    }
                }
            }
        }
        a
    };
    text.push_str("\n--- attrs ---\n");
    text.push_str(&attrs);
    std::fs::write(out, text).unwrap();
    s.send("\x03");
}

fn list_session() -> Session {
    let mut s = Session::spawn(30, 100);
    s.wait_for("skill_Manag");
    s.send("\r");
    s.wait_for("400 installed");
    s
}

fn to_menu_by(seq: &str, what: &str) {
    let mut s = list_session();
    s.send(seq);
    let end = Instant::now() + Duration::from_secs(2);
    while !s.text().contains("description line") {
        assert!(Instant::now() < end, "{what} ({seq:?}) did not go back; screen:\n{}", s.text());
        thread::sleep(Duration::from_millis(15));
    }
}

#[test]
fn key_alt_left_xterm_form() {
    to_menu_by("\x1b[1;3D", "alt+left xterm");
}

#[test]
fn key_alt_left_esc_prefixed_form() {
    to_menu_by("\x1b\x1b[D", "alt+left ESC-prefix");
}

#[test]
fn key_lone_escape_is_recognised() {
    to_menu_by("\x1b", "lone Esc");
}

#[test]
fn key_arrows_normal_and_application_mode() {
    let mut s = list_session();
    s.send("\x1b[B"); // CSI B
    s.send("\x1bOB"); // SS3 B (application cursor mode)
    s.send("j");
    s.wait_for("rows 1");
    thread::sleep(Duration::from_millis(150));
    assert!(s.row(7).starts_with(">"), "3 downs expected cursor on item 3: row7={:?}", s.row(7));
}

#[test]
fn key_utf8_in_filter_and_paste() {
    let mut s = list_session();
    s.send("/日本");
    s.wait_for("filter: 日本");
    s.send("\x15"); // ctrl+u clears the line
    s.send("emoji🚀");
    s.wait_for("filter: emoji🚀");
}

#[test]
fn key_question_mark_opens_help_and_any_key_closes() {
    let mut s = list_session();
    s.send("?");
    s.wait_for("keys");
    s.send("x");
    let end = Instant::now() + Duration::from_secs(2);
    while s.text().contains(" keys ") {
        assert!(Instant::now() < end, "help overlay did not close");
        thread::sleep(Duration::from_millis(15));
    }
}
