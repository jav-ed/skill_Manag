use proto::app::{App, Scan, Screen};
use proto::event::{EngineEvent, Event};
use proto::hit::Target;
use proto::ui;
use proto::worker::make_rows;
use ratatui::backend::TestBackend;
use proto::input::{Button, Code as KeyCode, Input, Key, KeyKind, Mods, Mouse, MouseKind as MouseEventKind};
use ratatui::Terminal;
use std::sync::mpsc;
use std::time::Duration;

pub fn list_app(rows: usize) -> App {
    let (tx, _rx) = mpsc::channel();
    let mut app = App::new(tx, rows, Duration::ZERO);
    app.screen = Screen::List;
    app.scan = Scan::Running { found: 0 };
    app.handle(Event::Engine(EngineEvent::ScanDone(make_rows(rows))));
    app
}

pub fn term(w: u16, h: u16) -> Terminal<TestBackend> {
    Terminal::new(TestBackend::new(w, h)).unwrap()
}

pub fn draw(t: &mut Terminal<TestBackend>, app: &mut App) {
    t.draw(|f| ui::draw(f, app)).unwrap();
}

pub fn mouse(kind: MouseEventKind, column: u16, row: u16) -> Event {
    Event::Term(Input::Mouse(Mouse { kind, column, row }))
}

pub fn click(x: u16, y: u16) -> Event {
    mouse(MouseEventKind::Down(Button::Left), x, y)
}

pub fn key(c: KeyCode) -> Event {
    Event::Term(Input::Key(Key::press(c)))
}

pub fn key_release(c: KeyCode) -> Event {
    Event::Term(Input::Key(Key { code: c, mods: Mods::NONE, kind: KeyKind::Release }))
}

/// Centre of the first rect registered for the target.
pub fn centre(app: &App, t: Target) -> (u16, u16) {
    let r = app.hits.rect_of(t).expect("target not rendered");
    (r.x + r.width / 2, r.y + r.height / 2)
}
