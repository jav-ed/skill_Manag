mod common;
use common::*;
use proto::app::{Effect, Screen};
use proto::hit::Target;
use proto::input::{Code as KeyCode, MouseKind as MouseEventKind};

#[test]
fn click_on_row_toggles_that_row_whatever_the_layout() {
    for (w, h) in [(80, 24), (60, 12), (120, 40)] {
        let mut app = list_app(400);
        let mut t = term(w, h);
        draw(&mut t, &mut app);
        let (x, y) = centre(&app, Target::Row(2));
        app.handle(click(x, y));
        assert_eq!(app.view.cursor, 2);
        assert!(app.view.selected.contains(&2), "{w}x{h}: row 2 not toggled");
    }
}

#[test]
fn wheel_scrolls_and_clicks_after_scrolling_hit_the_right_row() {
    let mut app = list_app(400);
    let mut t = term(80, 24);
    draw(&mut t, &mut app);
    let (x, y) = centre(&app, Target::Row(0));
    for _ in 0..10 {
        app.handle(mouse(MouseEventKind::ScrollDown, x, y));
    }
    draw(&mut t, &mut app);
    assert_eq!(app.view.offset, 30);
    let (x, y) = centre(&app, Target::Row(32));
    app.handle(click(x, y));
    assert!(app.view.selected.contains(&32));
}

#[test]
fn hover_moves_cursor_and_marks_header_link() {
    let mut app = list_app(400);
    let mut t = term(80, 24);
    draw(&mut t, &mut app);
    let (x, y) = centre(&app, Target::Row(4));
    app.handle(mouse(MouseEventKind::Moved, x, y));
    assert_eq!(app.view.cursor, 4);
    let (x, y) = centre(&app, Target::HeaderLink);
    app.handle(mouse(MouseEventKind::Moved, x, y));
    assert_eq!(app.hover, Some(Target::HeaderLink));
    draw(&mut t, &mut app);
    // OSC 8 squeezes the whole link into its first cell, so the style lives there.
    let first = app.hits.rect_of(Target::HeaderLink).unwrap();
    let cell = &t.backend().buffer()[(first.x, first.y)];
    assert!(cell.modifier.contains(ratatui::style::Modifier::UNDERLINED));
    app.handle(click(x, y));
    assert_eq!(app.effects, vec![Effect::OpenUrl("https://example.com".into())]);
}

#[test]
fn overlay_swallows_clicks_and_dismiss_area_closes_it() {
    let mut app = list_app(400);
    let mut t = term(80, 24);
    app.show_help = true;
    draw(&mut t, &mut app);
    // A click that would hit row 0 underneath must not toggle it.
    let (x, y) = centre(&app, Target::Overlay);
    app.handle(click(x, y));
    assert!(app.view.selected.is_empty() && app.show_help);
    app.handle(click(0, 0));
    assert!(!app.show_help);
}

#[test]
fn back_arrow_returns_to_menu_and_scrollbar_track_jumps() {
    let mut app = list_app(400);
    let mut t = term(80, 24);
    draw(&mut t, &mut app);
    let track = app.hits.rect_of(Target::ScrollTrack).unwrap();
    app.handle(click(track.x, track.y + track.height / 2));
    assert!(app.view.offset > 150 && app.view.offset < 250, "offset {}", app.view.offset);
    let (x, y) = centre(&app, Target::HeaderBack);
    app.handle(click(x, y));
    assert_eq!(app.screen, Screen::Menu);
}

#[test]
fn key_release_events_are_ignored_windows() {
    let mut app = list_app(10);
    app.handle(key(KeyCode::Char(' ')));
    app.handle(key_release(KeyCode::Char(' ')));
    assert_eq!(app.view.selected.len(), 1, "release must not toggle twice");
}

#[test]
fn stale_hits_after_resize_are_rebuilt_on_next_draw() {
    let mut app = list_app(400);
    let mut t = term(80, 24);
    draw(&mut t, &mut app);
    let before = app.hits.rect_of(Target::Row(0)).unwrap();
    t.backend_mut().resize(100, 30);
    draw(&mut t, &mut app);
    let after = app.hits.rect_of(Target::Row(0)).unwrap();
    assert!(after.width > before.width);
}
