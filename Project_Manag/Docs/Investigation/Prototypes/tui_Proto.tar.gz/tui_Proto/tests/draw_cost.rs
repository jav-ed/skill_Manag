mod common;
use common::*;
use std::time::Instant;

#[test]
fn draw_cost_400_and_20000_rows() {
    for n in [400usize, 20_000] {
        let mut app = list_app(n);
        let mut t = term(200, 60);
        draw(&mut t, &mut app);
        let frames = 500;
        let start = Instant::now();
        for i in 0..frames {
            app.scroll(if i % 2 == 0 { 7 } else { -5 });
            draw(&mut t, &mut app);
        }
        let per = start.elapsed() / frames;
        println!("rows={n} 200x60 draw+diff: {per:?} per frame");
    }
}
