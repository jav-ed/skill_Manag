use proto::app::{App, Effect};
use proto::event::{Event, InputThread};
use proto::ui;
use proto::backend::{self, AppTerminal};
use std::sync::mpsc;
use std::time::Duration;

fn main() -> std::io::Result<()> {
    let (tx, rx) = mpsc::channel::<Event>();
    let (mut terminal, source) = backend::start()?;
    let input = InputThread::spawn(tx.clone(), source);
    let scan_total = std::env::var("PROTO_ROWS").ok().and_then(|s| s.parse().ok()).unwrap_or(400);
    let mut app = App::new(tx, scan_total, Duration::from_millis(15));
    let result = run(&mut terminal, &mut app, &rx);
    drop(input);
    backend::stop(&mut terminal)?;
    result
}

fn run(terminal: &mut AppTerminal, app: &mut App, rx: &mpsc::Receiver<Event>) -> std::io::Result<()> {
    let (mut draws, mut events) = (0u64, 0u64);
    let started = std::time::Instant::now();
    while !app.quit {
        terminal.draw(|f| ui::draw(f, app))?;
        draws += 1;
        // Block until something happens; tick only while something animates.
        let first = if app.animating() {
            match rx.recv_timeout(Duration::from_millis(80)) {
                Ok(ev) => Some(ev),
                Err(mpsc::RecvTimeoutError::Timeout) => {
                    app.on_tick();
                    None
                }
                Err(mpsc::RecvTimeoutError::Disconnected) => break,
            }
        } else {
            rx.recv().ok()
        };
        let Some(first) = first else { continue };
        app.handle(first);
        events += 1;
        // Coalesce: drain everything queued (mouse motion floods, resize bursts) before redrawing.
        while let Ok(ev) = rx.try_recv() {
            app.handle(ev);
            events += 1;
        }
        for eff in app.effects.drain(..) {
            let Effect::OpenUrl(url) = eff;
            let _ = url; // real code: `open` crate, or spawn xdg-open
        }
    }
    if let Ok(path) = std::env::var("PROTO_STATS_FILE") {
        let _ = std::fs::write(path, format!("draws={draws} events={events} elapsed={:?}\n", started.elapsed()));
    }
    Ok(())
}
