//! One channel feeds the main loop: terminal input thread plus worker threads.
use crate::backend::InputSource;
use crate::input::Input;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::Sender;
use std::sync::Arc;
use std::thread::{self, JoinHandle};
use std::time::Duration;

#[derive(Debug, Clone)]
pub struct Row {
    pub name: String,
    pub project: String,
}

#[derive(Debug)]
pub enum EngineEvent {
    ScanProgress { found: usize },
    ScanDone(Vec<Row>),
    ApplyProgress { done: usize, total: usize },
    ApplyDone,
}

#[derive(Debug)]
pub enum Event {
    Term(Input),
    Engine(EngineEvent),
}

/// Reads terminal events on its own thread. Joinable: polls with a short timeout and checks a flag,
/// so a leaked blocking `read()` can never steal keystrokes after the TUI has ended.
pub struct InputThread {
    stop: Arc<AtomicBool>,
    handle: Option<JoinHandle<()>>,
}

impl InputThread {
    pub fn spawn(tx: Sender<Event>, source: InputSource) -> Self {
        let stop = Arc::new(AtomicBool::new(false));
        let flag = stop.clone();
        let handle = thread::spawn(move || {
            while !flag.load(Ordering::Relaxed) {
                match source.poll(Duration::from_millis(50)) {
                    Ok(Some(input)) => {
                        if tx.send(Event::Term(input)).is_err() {
                            break;
                        }
                    }
                    Ok(None) => {}
                    Err(_) => break,
                }
            }
        });
        Self { stop, handle: Some(handle) }
    }
}

impl Drop for InputThread {
    fn drop(&mut self) {
        self.stop.store(true, Ordering::Relaxed);
        if let Some(h) = self.handle.take() {
            let _ = h.join();
        }
    }
}
