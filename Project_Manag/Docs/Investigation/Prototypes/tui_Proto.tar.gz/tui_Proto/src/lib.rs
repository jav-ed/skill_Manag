//! Prototype: persistent app, screen router, stored-Rect hit testing.
pub mod app;
pub mod backend;
pub mod binding;
pub mod event;
pub mod filter;
pub mod hit;
pub mod input;
pub mod picker;
pub mod ui;
pub mod worker;
