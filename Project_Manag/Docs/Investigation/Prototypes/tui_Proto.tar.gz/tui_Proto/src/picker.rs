//! Directory picker (replaces bubbles `filepicker` with DirAllowed, no files). Mouse via HitMap.
use crate::hit::{HitMap, Target};
use crate::input::{Button, Code, Key, Mouse, MouseKind};
use ratatui::layout::{Constraint, Layout, Position, Rect};
use ratatui::style::{Color, Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Paragraph, Scrollbar, ScrollbarOrientation, ScrollbarState};
use ratatui::Frame;
use std::path::{Path, PathBuf};

pub struct Picker {
    pub cwd: PathBuf,
    pub dirs: Vec<String>,
    pub cursor: usize,
    pub offset: usize,
    pub show_hidden: bool,
    /// Set when a directory could not be read; shown, never swallowed.
    pub error: Option<String>,
    viewport: usize,
    hits: HitMap,
}

pub enum Outcome {
    Pending,
    Chosen(PathBuf),
}

impl Picker {
    pub fn new(start: &Path) -> std::io::Result<Self> {
        let mut p = Self { cwd: PathBuf::new(), dirs: Vec::new(), cursor: 0, offset: 0, show_hidden: false, error: None, viewport: 10, hits: HitMap::default() };
        p.cd(start)?;
        Ok(p)
    }

    fn cd(&mut self, path: &Path) -> std::io::Result<()> {
        let mut dirs = Vec::new();
        for e in std::fs::read_dir(path)? {
            let e = e?;
            let name = e.file_name().to_string_lossy().into_owned();
            // metadata() follows symlinks, so a link to a directory is listed as a directory
            if e.metadata().map(|m| m.is_dir()).unwrap_or(false) && (self.show_hidden || !name.starts_with('.')) {
                dirs.push(name);
            }
        }
        dirs.sort_by_key(|n| n.to_lowercase());
        self.cwd = path.to_path_buf();
        self.dirs = dirs;
        self.cursor = 0;
        self.offset = 0;
        self.error = None;
        Ok(())
    }

    fn try_cd(&mut self, path: &Path) {
        if let Err(e) = self.cd(path) {
            self.error = Some(format!("{}: {e}", path.display()));
        }
    }

    fn enter(&mut self) {
        if let Some(name) = self.dirs.get(self.cursor).cloned() {
            let next = self.cwd.join(name);
            self.try_cd(&next);
        }
    }

    fn up(&mut self) {
        if let Some(parent) = self.cwd.parent().map(Path::to_path_buf) {
            self.try_cd(&parent);
        }
    }

    fn step(&mut self, d: isize) {
        let max = self.dirs.len().saturating_sub(1) as isize;
        self.cursor = (self.cursor as isize + d).clamp(0, max) as usize;
        let h = self.viewport.max(1);
        if self.cursor < self.offset {
            self.offset = self.cursor;
        } else if self.cursor >= self.offset + h {
            self.offset = self.cursor + 1 - h;
        }
    }

    pub fn on_key(&mut self, k: &Key) -> Outcome {
        match k.code {
            Code::Up | Code::Char('k') => self.step(-1),
            Code::Down | Code::Char('j') => self.step(1),
            Code::PageUp => self.step(-(self.viewport as isize)),
            Code::PageDown => self.step(self.viewport as isize),
            Code::Right | Code::Char('l') => self.enter(),
            Code::Left | Code::Char('h') | Code::Backspace => self.up(),
            Code::Char('.') => {
                self.show_hidden = !self.show_hidden;
                let here = self.cwd.clone();
                self.try_cd(&here);
            }
            Code::Enter => return Outcome::Chosen(self.cwd.clone()),
            _ => {}
        }
        Outcome::Pending
    }

    pub fn on_mouse(&mut self, m: &Mouse) -> Outcome {
        let target = self.hits.at(Position::new(m.column, m.row));
        match (m.kind, target) {
            (MouseKind::Moved, Some(Target::PickerRow(i))) => self.cursor = i,
            (MouseKind::ScrollDown, Some(Target::PickerRow(_))) => self.step(3),
            (MouseKind::ScrollUp, Some(Target::PickerRow(_))) => self.step(-3),
            (MouseKind::Down(Button::Left), Some(Target::PickerRow(i))) => {
                // first click selects, click on the selected row opens it
                if self.cursor == i {
                    self.enter();
                } else {
                    self.cursor = i;
                }
            }
            (MouseKind::Down(Button::Left), Some(Target::PickerUp)) => self.up(),
            (MouseKind::Down(Button::Left), Some(Target::PickerHidden)) => {
                self.show_hidden = !self.show_hidden;
                let here = self.cwd.clone();
                self.try_cd(&here);
            }
            (MouseKind::Down(Button::Left), Some(Target::PickerSelect)) => return Outcome::Chosen(self.cwd.clone()),
            _ => {}
        }
        Outcome::Pending
    }

    pub fn hits(&self) -> &HitMap {
        &self.hits
    }

    pub fn draw(&mut self, frame: &mut Frame, area: Rect) {
        self.hits.clear();
        let [bar, list, foot] = Layout::vertical([Constraint::Length(1), Constraint::Fill(1), Constraint::Length(1)]).areas(area);
        let accent = Style::new().fg(Color::Cyan);
        let up = Rect::new(bar.x, bar.y, 4, 1);
        frame.render_widget(Paragraph::new(Span::styled(" ⬑  ", accent)), up);
        self.hits.push(up, Target::PickerUp);
        let path = Rect::new(bar.x + 4, bar.y, bar.width.saturating_sub(4), 1);
        frame.render_widget(Paragraph::new(self.cwd.display().to_string()), path);

        self.viewport = list.height as usize;
        for (vi, name) in self.dirs.iter().skip(self.offset).take(list.height as usize).enumerate() {
            let i = self.offset + vi;
            let row = Rect::new(list.x, list.y + vi as u16, list.width.saturating_sub(1), 1);
            let at = i == self.cursor;
            let style = if at { accent.add_modifier(Modifier::BOLD) } else { Style::new() };
            frame.render_widget(Paragraph::new(Line::styled(format!("{}{name}/", if at { "> " } else { "  " }), style)), row);
            self.hits.push(row, Target::PickerRow(i));
        }
        if self.dirs.is_empty() {
            frame.render_widget(Paragraph::new(Span::styled("  (no sub-directories)", Style::new().fg(Color::DarkGray))), list);
        }
        let track = Rect::new(list.right().saturating_sub(1), list.y, 1, list.height);
        let mut sb = ScrollbarState::new(self.dirs.len()).position(self.offset).viewport_content_length(list.height as usize);
        frame.render_stateful_widget(Scrollbar::new(ScrollbarOrientation::VerticalRight).begin_symbol(None).end_symbol(None), track, &mut sb);

        let [hidden, select] = Layout::horizontal([Constraint::Length(18), Constraint::Fill(1)]).areas(foot);
        let label = if self.show_hidden { " [x] hidden (.)" } else { " [ ] hidden (.)" };
        frame.render_widget(Paragraph::new(label), hidden);
        self.hits.push(hidden, Target::PickerHidden);
        let msg = self.error.clone().map(|e| Span::styled(format!("error: {e}"), Style::new().fg(Color::Red))).unwrap_or_else(|| Span::styled("[ select this folder: enter ]", accent));
        frame.render_widget(Paragraph::new(msg), select);
        if self.error.is_none() {
            self.hits.push(select, Target::PickerSelect);
        }
    }
}
