//! Terminal backend selection: exactly one of the features `crossterm` or `termina`.
#[cfg(all(feature = "crossterm", feature = "termina"))]
compile_error!("enable only one of the features `crossterm` and `termina`");
#[cfg(not(any(feature = "crossterm", feature = "termina")))]
compile_error!("enable one of the features `crossterm` or `termina`");

#[cfg(feature = "crossterm")]
mod crossterm_be;
#[cfg(feature = "crossterm")]
pub use crossterm_be::*;

#[cfg(feature = "termina")]
mod termina_be;
#[cfg(feature = "termina")]
pub use termina_be::*;
