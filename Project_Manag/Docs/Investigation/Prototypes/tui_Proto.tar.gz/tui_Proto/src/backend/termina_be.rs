use crate::input::{Button, Code, Input, Key, KeyKind, Mods, Mouse, MouseKind};
use ratatui::Terminal;
use ratatui_termina::termina::escape::csi::{self, Csi};
use ratatui_termina::termina::event::{KeyCode, KeyEventKind, Modifiers, MouseButton, MouseEventKind};
use ratatui_termina::termina::{Event, EventReader, PlatformTerminal, Terminal as _};
use ratatui_termina::TerminaBackend;
use std::io::{self, Write as _};
use std::time::Duration;

pub type AppTerminal = Terminal<TerminaBackend<PlatformTerminal>>;

pub struct InputSource(EventReader);

fn set(mode: csi::DecPrivateModeCode) -> Csi {
    Csi::Mode(csi::Mode::SetDecPrivateMode(csi::DecPrivateMode::Code(mode)))
}
fn reset(mode: csi::DecPrivateModeCode) -> Csi {
    Csi::Mode(csi::Mode::ResetDecPrivateMode(csi::DecPrivateMode::Code(mode)))
}

pub fn start() -> io::Result<(AppTerminal, InputSource)> {
    use csi::DecPrivateModeCode::*;
    let mut out = PlatformTerminal::new()?;
    out.enter_raw_mode()?;
    write!(out, "{}{}{}{}{}{}", set(ClearAndEnableAlternateScreen), set(MouseTracking), set(ButtonEventMouse), set(AnyEventMouse), set(RXVTMouse), set(SGRMouse))?;
    out.flush()?;
    let reader = out.event_reader();
    // The backend does not install a panic hook: restore the terminal modes ourselves.
    let default_hook = std::panic::take_hook();
    std::panic::set_hook(Box::new(move |info| {
        let mut e = io::stderr();
        let _ = write!(e, "\x1b[?1006l\x1b[?1015l\x1b[?1003l\x1b[?1002l\x1b[?1000l\x1b[?1049l\x1b[?25h");
        default_hook(info);
    }));
    let terminal = Terminal::new(TerminaBackend::new(out))?;
    Ok((terminal, InputSource(reader)))
}

pub fn stop(t: &mut AppTerminal) -> io::Result<()> {
    use csi::DecPrivateModeCode::*;
    let b = t.backend_mut();
    write!(b, "{}{}{}{}{}{}{}", reset(SGRMouse), reset(RXVTMouse), reset(AnyEventMouse), reset(ButtonEventMouse), reset(MouseTracking), reset(ClearAndEnableAlternateScreen), set(ShowCursor))?;
    b.flush()
}

impl InputSource {
    pub fn poll(&self, timeout: Duration) -> io::Result<Option<Input>> {
        let wanted = |e: &Event| !e.is_escape();
        if !self.0.poll(Some(timeout), wanted)? {
            return Ok(None);
        }
        Ok(Some(convert(self.0.read(wanted)?)))
    }
}

fn convert(ev: Event) -> Input {
    match ev {
        Event::Key(k) => {
            let code = match k.code {
                KeyCode::Char(c) => Code::Char(c),
                KeyCode::Enter => Code::Enter,
                KeyCode::Escape => Code::Esc,
                KeyCode::Tab => Code::Tab,
                KeyCode::Backspace => Code::Backspace,
                KeyCode::Delete => Code::Delete,
                KeyCode::Up => Code::Up,
                KeyCode::Down => Code::Down,
                KeyCode::Left => Code::Left,
                KeyCode::Right => Code::Right,
                KeyCode::Home => Code::Home,
                KeyCode::End => Code::End,
                KeyCode::PageUp => Code::PageUp,
                KeyCode::PageDown => Code::PageDown,
                _ => return Input::Ignored,
            };
            let mut mods = 0;
            if k.modifiers.contains(Modifiers::SHIFT) {
                mods |= Mods::SHIFT.0;
            }
            if k.modifiers.contains(Modifiers::ALT) {
                mods |= Mods::ALT.0;
            }
            if k.modifiers.contains(Modifiers::CONTROL) {
                mods |= Mods::CTRL.0;
            }
            let kind = match k.kind {
                KeyEventKind::Press => KeyKind::Press,
                KeyEventKind::Repeat => KeyKind::Repeat,
                KeyEventKind::Release => KeyKind::Release,
            };
            Input::Key(Key { code, mods: Mods(mods), kind })
        }
        Event::Mouse(m) => {
            let btn = |b: MouseButton| match b {
                MouseButton::Left => Button::Left,
                MouseButton::Right => Button::Right,
                MouseButton::Middle => Button::Middle,
            };
            let kind = match m.kind {
                MouseEventKind::Moved => MouseKind::Moved,
                MouseEventKind::Down(b) => MouseKind::Down(btn(b)),
                MouseEventKind::Up(b) => MouseKind::Up(btn(b)),
                MouseEventKind::Drag(b) => MouseKind::Drag(btn(b)),
                MouseEventKind::ScrollUp => MouseKind::ScrollUp,
                MouseEventKind::ScrollDown => MouseKind::ScrollDown,
                _ => return Input::Ignored,
            };
            Input::Mouse(Mouse { kind, column: m.column, row: m.row })
        }
        Event::WindowResized(_) => Input::Resize,
        _ => Input::Ignored,
    }
}
