use crate::input::{Button, Code, Input, Key, KeyKind, Mods, Mouse, MouseKind};
use ratatui::crossterm::event::{self, Event, KeyCode, KeyEventKind, KeyModifiers, MouseButton, MouseEventKind};
use ratatui::crossterm::execute;
use ratatui::DefaultTerminal;
use std::io::{self, stdout};
use std::time::Duration;

pub type AppTerminal = DefaultTerminal;

pub struct InputSource;

pub fn start() -> io::Result<(AppTerminal, InputSource)> {
    let terminal = ratatui::try_init()?; // raw mode, alt screen, panic hook
    execute!(stdout(), event::EnableMouseCapture)?; // 1000+1002+1003 (any motion)+1015+1006 (SGR)
    Ok((terminal, InputSource))
}

pub fn stop(_t: &mut AppTerminal) -> io::Result<()> {
    execute!(stdout(), event::DisableMouseCapture)?;
    ratatui::try_restore()
}

impl InputSource {
    pub fn poll(&self, timeout: Duration) -> io::Result<Option<Input>> {
        if !event::poll(timeout)? {
            return Ok(None);
        }
        Ok(Some(convert(event::read()?)))
    }
}

fn convert(ev: Event) -> Input {
    match ev {
        Event::Key(k) => {
            let code = match k.code {
                KeyCode::Char(c) => Code::Char(c),
                KeyCode::Enter => Code::Enter,
                KeyCode::Esc => Code::Esc,
                KeyCode::Tab => Code::Tab,
                KeyCode::Backspace => Code::Backspace,
                KeyCode::Delete => Code::Delete,
                KeyCode::Up => Code::Up,
                KeyCode::Down => Code::Down,
                KeyCode::Left => Code::Left,
                KeyCode::Right => Code::Right,
                KeyCode::Home => Code::Home,
                KeyCode::End => Code::End,
                KeyCode::PageUp => Code::PageUp,
                KeyCode::PageDown => Code::PageDown,
                _ => return Input::Ignored,
            };
            let mut mods = 0;
            if k.modifiers.contains(KeyModifiers::SHIFT) {
                mods |= Mods::SHIFT.0;
            }
            if k.modifiers.contains(KeyModifiers::ALT) {
                mods |= Mods::ALT.0;
            }
            if k.modifiers.contains(KeyModifiers::CONTROL) {
                mods |= Mods::CTRL.0;
            }
            let kind = match k.kind {
                KeyEventKind::Press => KeyKind::Press,
                KeyEventKind::Repeat => KeyKind::Repeat,
                KeyEventKind::Release => KeyKind::Release,
            };
            Input::Key(Key { code, mods: Mods(mods), kind })
        }
        Event::Mouse(m) => {
            let btn = |b: MouseButton| match b {
                MouseButton::Left => Button::Left,
                MouseButton::Right => Button::Right,
                MouseButton::Middle => Button::Middle,
            };
            let kind = match m.kind {
                MouseEventKind::Moved => MouseKind::Moved,
                MouseEventKind::Down(b) => MouseKind::Down(btn(b)),
                MouseEventKind::Up(b) => MouseKind::Up(btn(b)),
                MouseEventKind::Drag(b) => MouseKind::Drag(btn(b)),
                MouseEventKind::ScrollUp => MouseKind::ScrollUp,
                MouseEventKind::ScrollDown => MouseKind::ScrollDown,
                _ => return Input::Ignored,
            };
            Input::Mouse(Mouse { kind, column: m.column, row: m.row })
        }
        Event::Resize(..) => Input::Resize,
        _ => Input::Ignored,
    }
}
