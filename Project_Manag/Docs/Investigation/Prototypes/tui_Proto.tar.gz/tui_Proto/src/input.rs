//! Backend-neutral input types. The app never sees crossterm or termina types, so the terminal
//! library can be swapped (or fixed upstream) without touching app, bindings or tests.
use tui_input::InputRequest;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Code {
    Char(char),
    Enter,
    Esc,
    Tab,
    Backspace,
    Delete,
    Up,
    Down,
    Left,
    Right,
    Home,
    End,
    PageUp,
    PageDown,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Mods(pub u8);
impl Mods {
    pub const NONE: Mods = Mods(0);
    pub const SHIFT: Mods = Mods(1);
    pub const ALT: Mods = Mods(2);
    pub const CTRL: Mods = Mods(4);
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum KeyKind {
    Press,
    Repeat,
    Release,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Key {
    pub code: Code,
    pub mods: Mods,
    pub kind: KeyKind,
}

impl Key {
    pub fn press(code: Code) -> Self {
        Self { code, mods: Mods::NONE, kind: KeyKind::Press }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Button {
    Left,
    Right,
    Middle,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MouseKind {
    Moved,
    Down(Button),
    Up(Button),
    Drag(Button),
    ScrollUp,
    ScrollDown,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Mouse {
    pub kind: MouseKind,
    pub column: u16,
    pub row: u16,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Input {
    Key(Key),
    Mouse(Mouse),
    Resize,
    /// Focus, paste markers and anything the app does not use.
    Ignored,
}

/// Editing keys for a single-line text field (emacs style, like tui-input's own backends).
pub fn to_request(k: &Key) -> Option<InputRequest> {
    use InputRequest::*;
    if k.kind == KeyKind::Release {
        return None;
    }
    match (k.code, k.mods) {
        (Code::Backspace, Mods::NONE) => Some(DeletePrevChar),
        (Code::Delete, Mods::NONE) => Some(DeleteNextChar),
        (Code::Left, Mods::NONE) => Some(GoToPrevChar),
        (Code::Right, Mods::NONE) => Some(GoToNextChar),
        (Code::Left, Mods::CTRL) => Some(GoToPrevWord),
        (Code::Right, Mods::CTRL) => Some(GoToNextWord),
        (Code::Home, Mods::NONE) | (Code::Char('a'), Mods::CTRL) => Some(GoToStart),
        (Code::End, Mods::NONE) | (Code::Char('e'), Mods::CTRL) => Some(GoToEnd),
        (Code::Char('u'), Mods::CTRL) => Some(DeleteLine),
        (Code::Char('w'), Mods::CTRL) => Some(DeletePrevWord),
        (Code::Char(c), Mods::NONE | Mods::SHIFT) => Some(InsertChar(c)),
        _ => None,
    }
}
