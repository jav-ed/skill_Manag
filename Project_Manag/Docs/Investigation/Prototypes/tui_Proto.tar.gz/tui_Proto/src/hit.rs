//! Hit map: rectangles recorded while rendering, queried while handling the mouse.
use ratatui::layout::{Position, Rect};

/// What a screen region means. Add one variant per clickable thing.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Target {
    HeaderBack,
    HeaderLink,
    MenuItem(usize),
    /// Index into the filtered list (not the viewport row).
    Row(usize),
    /// Whole list body, so the wheel works over gaps.
    ListArea,
    ScrollTrack,
    PickerRow(usize),
    PickerUp,
    PickerSelect,
    PickerHidden,
    /// Inside an overlay: swallow the event.
    Overlay,
    /// Behind an overlay: click closes it.
    Dismiss,
}

/// Regions in paint order. The last pushed region is the topmost one.
#[derive(Debug, Default, Clone)]
pub struct HitMap {
    entries: Vec<(Rect, Target)>,
}

impl HitMap {
    pub fn clear(&mut self) {
        self.entries.clear();
    }

    pub fn push(&mut self, rect: Rect, target: Target) {
        if rect.area() > 0 {
            self.entries.push((rect, target));
        }
    }

    /// Topmost region containing the position.
    pub fn at(&self, pos: Position) -> Option<Target> {
        self.entries.iter().rev().find(|(r, _)| r.contains(pos)).map(|(_, t)| *t)
    }

    /// Rect of the first region with this target (used by tests and scrollbar maths).
    pub fn rect_of(&self, target: Target) -> Option<Rect> {
        self.entries.iter().rev().find(|(_, t)| *t == target).map(|(r, _)| *r)
    }
}
