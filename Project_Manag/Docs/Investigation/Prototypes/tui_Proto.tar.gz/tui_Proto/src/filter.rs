//! Fuzzy filter over row names with match indices for highlighting.
use nucleo_matcher::pattern::{CaseMatching, Normalization, Pattern};
use nucleo_matcher::{Config, Matcher, Utf32Str};

pub struct Fuzzy {
    matcher: Matcher,
}

impl Default for Fuzzy {
    fn default() -> Self {
        Self { matcher: Matcher::new(Config::DEFAULT) }
    }
}

impl Fuzzy {
    /// Returns (original index, matched char indices) sorted by score, best first.
    pub fn run<'a>(&mut self, query: &str, names: impl Iterator<Item = &'a str>) -> Vec<(usize, Vec<u32>)> {
        let pattern = Pattern::parse(query, CaseMatching::Smart, Normalization::Smart);
        let mut buf = Vec::new();
        let mut out: Vec<(u32, usize, Vec<u32>)> = Vec::new();
        for (i, name) in names.enumerate() {
            let hay = Utf32Str::new(name, &mut buf);
            let mut idx = Vec::new();
            if let Some(score) = pattern.indices(hay, &mut self.matcher, &mut idx) {
                idx.sort_unstable();
                idx.dedup();
                out.push((score, i, idx));
            }
        }
        out.sort_by(|a, b| b.0.cmp(&a.0).then(a.1.cmp(&b.1)));
        out.into_iter().map(|(_, i, idx)| (i, idx)).collect()
    }
}
