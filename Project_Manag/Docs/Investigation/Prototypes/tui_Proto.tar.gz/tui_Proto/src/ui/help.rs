use crate::app::{App, Screen};
use crate::binding::{Binding, LIST_HELP};
use crate::hit::Target;
use ratatui::layout::Rect;
use ratatui::style::{Color, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, Borders, Clear, Paragraph};
use ratatui::Frame;

pub fn draw_footer(frame: &mut Frame, app: &App, area: Rect) {
    let short: &[&Binding] = if app.screen == Screen::List { &LIST_HELP[2..] } else { &LIST_HELP[6..] };
    let mut spans = vec![Span::raw(" ")];
    for (i, b) in short.iter().enumerate() {
        if i > 0 {
            spans.push(Span::styled(" · ", Style::new().fg(Color::DarkGray)));
        }
        spans.push(Span::styled(b.key, Style::new().fg(Color::Gray)));
        spans.push(Span::styled(format!(" {}", b.desc), Style::new().fg(Color::DarkGray)));
    }
    frame.render_widget(Paragraph::new(Line::from(spans)), area);
}

pub fn draw_overlay(frame: &mut Frame, app: &mut App) {
    let full = frame.area();
    app.hits.push(full, Target::Dismiss);
    let h = (LIST_HELP.len() as u16 + 2).min(full.height);
    let w = 36.min(full.width);
    let rect = Rect::new(full.x + (full.width - w) / 2, full.y + (full.height - h) / 2, w, h);
    app.hits.push(rect, Target::Overlay);
    frame.render_widget(Clear, rect);
    let lines: Vec<Line> = LIST_HELP.iter().map(|b| Line::from(vec![Span::styled(format!("{:<10}", b.key), Style::new().fg(Color::Cyan)), Span::raw(b.desc)])).collect();
    frame.render_widget(Paragraph::new(lines).block(Block::default().borders(Borders::ALL).title(" keys ")), rect);
}
