use crate::app::{App, MENU};
use crate::hit::Target;
use ratatui::layout::Rect;
use ratatui::style::{Color, Modifier, Style};
use ratatui::text::Line;
use ratatui::widgets::Paragraph;
use ratatui::Frame;

pub fn draw(frame: &mut Frame, app: &mut App, area: Rect) {
    for (i, label) in MENU.iter().enumerate() {
        let row = Rect::new(area.x + 2, area.y + 1 + (i as u16) * 3, area.width.saturating_sub(4), 2);
        if row.bottom() > area.bottom() {
            break;
        }
        let sel = app.menu_cursor == i;
        let style = if sel { Style::new().fg(Color::Cyan).add_modifier(Modifier::BOLD) } else { Style::new() };
        let marker = if sel { "┃ " } else { "  " };
        let text = vec![Line::styled(format!("{marker}{label}"), style), Line::styled("  description line", Style::new().fg(Color::DarkGray))];
        frame.render_widget(Paragraph::new(text), row);
        app.hits.push(row, Target::MenuItem(i));
    }
}
