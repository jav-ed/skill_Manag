use super::link::Link;
use crate::app::{App, Screen};
use crate::hit::Target;
use ratatui::layout::Rect;
use ratatui::style::{Color, Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::Paragraph;
use ratatui::Frame;

pub const LINK_TEXT: &str = "example.com";

pub fn draw(frame: &mut Frame, app: &mut App, area: Rect) {
    let cyan = Style::new().fg(Color::Cyan);
    let mut spans = Vec::new();
    if app.screen != Screen::Menu {
        let hov = app.hover == Some(Target::HeaderBack);
        let style = if hov { cyan.add_modifier(Modifier::BOLD | Modifier::REVERSED) } else { cyan };
        spans.push(Span::styled(" ← ", style));
        app.hits.push(Rect::new(area.x, area.y, 3, 1), Target::HeaderBack);
    }
    let title = match app.screen {
        Screen::Menu => " skill_Manag ",
        Screen::List => " skill_Manag › list ",
    };
    spans.push(Span::styled(title, Style::new().add_modifier(Modifier::BOLD)));
    frame.render_widget(Paragraph::new(Line::from(spans)), area);

    let w = LINK_TEXT.len() as u16;
    let link_area = Rect::new(area.right().saturating_sub(w + 1), area.y, w, 1);
    let hov = app.hover == Some(Target::HeaderLink);
    let style = if hov { cyan.add_modifier(Modifier::UNDERLINED) } else { Style::new().fg(Color::DarkGray) };
    frame.render_widget(Link { text: LINK_TEXT, url: "https://example.com", style }, link_area);
    app.hits.push(link_area, Target::HeaderLink);
}
