//! Rendering. Every clickable region is registered in `app.hits` while it is drawn.
mod header;
mod help;
mod link;
mod list;
mod menu;

use crate::app::{App, Screen};
use ratatui::layout::{Constraint, Layout};
use ratatui::Frame;

pub fn draw(frame: &mut Frame, app: &mut App) {
    app.hits.clear();
    let [head, body, foot] = Layout::vertical([Constraint::Length(1), Constraint::Fill(1), Constraint::Length(1)]).areas(frame.area());
    header::draw(frame, app, head);
    match app.screen {
        Screen::Menu => menu::draw(frame, app, body),
        Screen::List => list::draw(frame, app, body),
    }
    help::draw_footer(frame, app, foot);
    if app.show_help {
        help::draw_overlay(frame, app);
    }
}
