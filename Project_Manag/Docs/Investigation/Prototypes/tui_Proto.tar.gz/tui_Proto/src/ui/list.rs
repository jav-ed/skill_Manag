use crate::app::{Apply, App, Scan};
use crate::hit::Target;
use ratatui::layout::{Constraint, Layout, Rect};
use ratatui::style::{Color, Modifier, Style};
use ratatui::text::{Line, Span};
use ratatui::widgets::{LineGauge, Paragraph, Scrollbar, ScrollbarOrientation, ScrollbarState};
use ratatui::{symbols, Frame};

const SPINNER: [&str; 10] = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"];
const DIM: Style = Style::new().fg(Color::DarkGray);
const ACCENT: Style = Style::new().fg(Color::Cyan);

pub fn draw(frame: &mut Frame, app: &mut App, area: Rect) {
    if let Scan::Running { found } = app.scan {
        let s = SPINNER[app.tick % SPINNER.len()];
        let line = Line::from(vec![Span::styled(format!(" {s} "), ACCENT), Span::styled(format!("Scanning projects… {found} found"), DIM)]);
        frame.render_widget(Paragraph::new(line), area);
        return;
    }
    let [title, filter, colhdr, items, status] =
        Layout::vertical([Constraint::Length(1), Constraint::Length(1), Constraint::Length(1), Constraint::Fill(1), Constraint::Length(1)]).areas(area);
    draw_title(frame, app, title);
    draw_filter(frame, app, filter);
    frame.render_widget(Paragraph::new(Span::styled("      [·] skill                       project", DIM)), colhdr);
    draw_items(frame, app, items);
    draw_status(frame, app, status);
}

fn draw_title(frame: &mut Frame, app: &App, area: Rect) {
    let v = &app.view;
    let text = if app.filter.value().is_empty() {
        format!(" Skills — {} installed", app.rows.len())
    } else {
        format!(" Skills — {} matching {:?}", v.filtered.len(), app.filter.value())
    };
    let sel = format!("   {} / {} selected", v.selected.len(), v.filtered.len());
    let line = Line::from(vec![Span::styled(text, Style::new().add_modifier(Modifier::BOLD)), Span::styled(sel, DIM)]);
    frame.render_widget(Paragraph::new(line), area);
}

fn draw_filter(frame: &mut Frame, app: &App, area: Rect) {
    if app.filtering {
        let scroll = app.filter.visual_scroll(area.width.saturating_sub(10) as usize);
        let line = Line::from(vec![Span::styled(" filter: ", Style::new().fg(Color::Yellow)), Span::raw(app.filter.value().to_string())]);
        frame.render_widget(Paragraph::new(line).scroll((0, scroll as u16)), area);
        let cx = area.x + 9 + (app.filter.visual_cursor().max(scroll) - scroll) as u16;
        frame.set_cursor_position((cx, area.y));
    } else {
        frame.render_widget(Paragraph::new(Span::styled(" / to filter", DIM)), area);
    }
}

fn draw_items(frame: &mut Frame, app: &mut App, area: Rect) {
    app.viewport = area.height as usize;
    app.ensure_visible();
    app.hits.push(area, Target::ListArea);
    let (len, h, offset) = (app.view.filtered.len(), area.height as usize, app.view.offset);
    for (vi, (row_idx, hits)) in app.view.filtered.iter().skip(offset).take(h).enumerate() {
        let fi = offset + vi;
        let rect = Rect::new(area.x, area.y + vi as u16, area.width.saturating_sub(1), 1);
        let [cur, chk, name, proj] = Layout::horizontal([Constraint::Length(2), Constraint::Length(4), Constraint::Length(26), Constraint::Fill(1)]).areas(rect);
        let row = &app.rows[*row_idx];
        let on = app.view.selected.contains(row_idx);
        let at_cursor = app.view.cursor == fi;
        frame.render_widget(Paragraph::new(if at_cursor { "> " } else { "  " }).style(ACCENT), cur);
        frame.render_widget(Paragraph::new(if on { "[✓]" } else { "[ ]" }).style(if on { ACCENT } else { Style::new() }), chk);
        frame.render_widget(Paragraph::new(highlight(&row.name, hits, at_cursor)), name);
        frame.render_widget(Paragraph::new(row.project.as_str()).style(DIM), proj);
        app.hits.push(rect, Target::Row(fi));
    }
    let track = Rect::new(area.right().saturating_sub(1), area.y, 1, area.height);
    app.hits.push(track, Target::ScrollTrack);
    let mut sb = ScrollbarState::new(len).position(offset).viewport_content_length(h);
    let bar = Scrollbar::new(ScrollbarOrientation::VerticalRight).begin_symbol(None).end_symbol(None).track_symbol(Some(symbols::line::VERTICAL));
    frame.render_stateful_widget(bar, track, &mut sb);
}

/// Matched characters bold yellow; the cursor row is bold.
fn highlight(name: &str, idx: &[u32], at_cursor: bool) -> Line<'static> {
    let base = if at_cursor { Style::new().add_modifier(Modifier::BOLD) } else { Style::new() };
    let spans: Vec<Span> = name
        .chars()
        .enumerate()
        .map(|(i, c)| {
            let s = if idx.binary_search(&(i as u32)).is_ok() { base.fg(Color::Yellow).add_modifier(Modifier::BOLD) } else { base };
            Span::styled(c.to_string(), s)
        })
        .collect();
    Line::from(spans)
}

fn draw_status(frame: &mut Frame, app: &App, area: Rect) {
    match app.apply {
        Apply::Running { done, total } => {
            let g = LineGauge::default().filled_style(ACCENT).unfilled_style(DIM).label(format!("Applying {done} / {total}")).ratio(done as f64 / total.max(1) as f64);
            frame.render_widget(g, area);
        }
        Apply::Done(n) => frame.render_widget(Paragraph::new(Span::styled(format!(" applied {n} skills"), Style::new().fg(Color::Green))), area),
        Apply::Idle => {
            let (len, off, h) = (app.view.filtered.len(), app.view.offset, app.viewport);
            let text = format!(" rows {}–{} of {}", (off + 1).min(len), (off + h).min(len), len);
            frame.render_widget(Paragraph::new(Span::styled(text, DIM)), area);
        }
    }
}
