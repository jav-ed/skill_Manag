//! OSC 8 hyperlink as a widget. Uses ratatui 0.30.1+ `CellDiffOption::ForcedWidth`.
use ratatui::buffer::{Buffer, CellDiffOption};
use ratatui::layout::Rect;
use ratatui::style::Style;
use ratatui::text::Span;
use ratatui::widgets::Widget;
use std::num::NonZeroU16;

pub struct Link<'a> {
    pub text: &'a str,
    pub url: &'a str,
    pub style: Style,
}

impl Widget for Link<'_> {
    fn render(self, area: Rect, buf: &mut Buffer) {
        let width = Span::raw(self.text).width().min(area.width as usize) as u16;
        let Some(width) = NonZeroU16::new(width) else { return };
        buf.set_stringn(area.x, area.y, self.text, area.width as usize, self.style);
        // Squeeze the whole escape sequence into the first cell and force its on-screen width.
        let sym = format!("\x1b]8;;{}\x1b\\{}\x1b]8;;\x1b\\", self.url, self.text);
        if let Some(cell) = buf.cell_mut((area.x, area.y)) {
            cell.set_symbol(&sym).set_diff_option(CellDiffOption::ForcedWidth(width));
        }
    }
}
