//! Fake engine: a scan and an apply that report progress without blocking the UI thread.
use crate::event::{EngineEvent, Event, Row};
use std::sync::mpsc::Sender;
use std::thread;
use std::time::Duration;

pub fn make_rows(n: usize) -> Vec<Row> {
    (0..n)
        .map(|i| {
            let name = match i % 50 {
                7 => format!("日本語-skill-{i:03}"),
                8 => format!("emoji-🚀-skill-{i:03}"),
                _ => format!("skill-{:03}", i % 97),
            };
            Row { name, project: format!("~/code/project-{:02}/.agents/skills", i % 60) }
        })
        .collect()
}

pub fn spawn_scan(tx: Sender<Event>, total: usize, delay: Duration) {
    thread::spawn(move || {
        for found in (0..total).step_by(20) {
            thread::sleep(delay);
            if tx.send(Event::Engine(EngineEvent::ScanProgress { found })).is_err() {
                return;
            }
        }
        let _ = tx.send(Event::Engine(EngineEvent::ScanDone(make_rows(total))));
    });
}

pub fn spawn_apply(tx: Sender<Event>, total: usize, delay: Duration) {
    thread::spawn(move || {
        for done in 1..=total {
            thread::sleep(delay);
            if tx.send(Event::Engine(EngineEvent::ApplyProgress { done, total })).is_err() {
                return;
            }
        }
        let _ = tx.send(Event::Engine(EngineEvent::ApplyDone));
    });
}
