//! Application state, screen router and update logic. No terminal access in here.
use crate::binding::{self, ALL, APPLY, BACK, DOWN, FILTER, HELP, QUIT, TOGGLE, UP};
use crate::event::{EngineEvent, Event, Row};
use crate::filter::Fuzzy;
use crate::hit::{HitMap, Target};
use crate::worker;
use crate::input::{self, Button, Code, Input, Key, KeyKind, Mouse, MouseKind};
use ratatui::layout::Position;
use std::collections::HashSet;
use std::sync::mpsc::Sender;
use std::time::Duration;
use tui_input::Input as TextInput;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Screen {
    Menu,
    List,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Scan {
    Idle,
    Running { found: usize },
    Done,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Apply {
    Idle,
    Running { done: usize, total: usize },
    Done(usize),
}

/// Side effects the main loop performs after `handle`, so `handle` stays testable.
#[derive(Debug, PartialEq, Eq)]
pub enum Effect {
    OpenUrl(String),
}

#[derive(Default)]
pub struct ListView {
    /// (index into App::rows, matched char indices of the name)
    pub filtered: Vec<(usize, Vec<u32>)>,
    pub cursor: usize,
    pub offset: usize,
    pub selected: HashSet<usize>,
}

pub struct App {
    pub screen: Screen,
    pub scan: Scan,
    pub apply: Apply,
    pub rows: Vec<Row>,
    pub view: ListView,
    pub menu_cursor: usize,
    pub filter: TextInput,
    pub filtering: bool,
    pub show_help: bool,
    pub hits: HitMap,
    pub hover: Option<Target>,
    pub tick: usize,
    pub quit: bool,
    pub effects: Vec<Effect>,
    /// Rows visible in the list body; written by the renderer, read by scrolling.
    pub viewport: usize,
    tx: Sender<Event>,
    fuzzy: Fuzzy,
    scan_total: usize,
    delay: Duration,
}

pub const MENU: [&str; 3] = ["List", "Sync", "Quit"];

impl App {
    pub fn new(tx: Sender<Event>, scan_total: usize, delay: Duration) -> Self {
        Self {
            screen: Screen::Menu,
            scan: Scan::Idle,
            apply: Apply::Idle,
            rows: Vec::new(),
            view: ListView::default(),
            menu_cursor: 0,
            filter: TextInput::default(),
            filtering: false,
            show_help: false,
            hits: HitMap::default(),
            hover: None,
            tick: 0,
            quit: false,
            effects: Vec::new(),
            viewport: 10,
            tx,
            fuzzy: Fuzzy::default(),
            scan_total,
            delay,
        }
    }

    /// Spinner and progress need ticks; everything else is purely event driven (zero idle CPU).
    pub fn animating(&self) -> bool {
        matches!(self.scan, Scan::Running { .. }) || matches!(self.apply, Apply::Running { .. })
    }

    pub fn on_tick(&mut self) {
        self.tick = self.tick.wrapping_add(1);
    }

    pub fn handle(&mut self, ev: Event) {
        match ev {
            Event::Term(Input::Key(k)) => self.on_key(k),
            Event::Term(Input::Mouse(m)) => self.on_mouse(m),
            // Resize needs no state change: the next draw re-lays-out and rebuilds the hit map.
            Event::Term(_) => {}
            Event::Engine(e) => self.on_engine(e),
        }
    }

    fn on_engine(&mut self, e: EngineEvent) {
        match e {
            EngineEvent::ScanProgress { found } => self.scan = Scan::Running { found },
            EngineEvent::ScanDone(rows) => {
                self.rows = rows;
                self.scan = Scan::Done;
                self.refilter();
            }
            EngineEvent::ApplyProgress { done, total } => self.apply = Apply::Running { done, total },
            EngineEvent::ApplyDone => {
                let n = self.view.selected.len();
                self.apply = Apply::Done(n);
            }
        }
    }

    pub fn refilter(&mut self) {
        let q = self.filter.value().to_string();
        self.view.filtered = if q.is_empty() {
            (0..self.rows.len()).map(|i| (i, Vec::new())).collect()
        } else {
            self.fuzzy.run(&q, self.rows.iter().map(|r| r.name.as_str()))
        };
        self.view.cursor = 0;
        self.view.offset = 0;
    }

    fn on_key(&mut self, k: Key) {
        if k.kind == KeyKind::Release {
            return;
        }
        if QUIT.matches(&k) {
            self.quit = true;
        } else if self.show_help {
            self.show_help = false;
        } else if self.screen == Screen::List && self.filtering {
            self.on_filter_key(k);
        } else if HELP.matches(&k) {
            self.show_help = true;
        } else if self.screen == Screen::Menu {
            self.on_menu_key(k);
        } else {
            self.on_list_key(k);
        }
    }

    fn on_filter_key(&mut self, k: Key) {
        match k.code {
            Code::Esc => {
                self.filter.reset();
                self.filtering = false;
                self.refilter();
            }
            Code::Enter => self.filtering = false,
            _ => {
                if let Some(req) = input::to_request(&k) {
                    if self.filter.handle(req).is_some() {
                        self.refilter();
                    }
                }
            }
        }
    }

    fn on_menu_key(&mut self, k: Key) {
        if UP.matches(&k) {
            self.menu_cursor = self.menu_cursor.saturating_sub(1);
        } else if DOWN.matches(&k) {
            self.menu_cursor = (self.menu_cursor + 1).min(MENU.len() - 1);
        } else if APPLY.matches(&k) {
            self.activate_menu(self.menu_cursor);
        } else if BACK.matches(&k) {
            self.quit = true;
        }
    }

    fn activate_menu(&mut self, i: usize) {
        match i {
            0 => self.open_list(),
            2 => self.quit = true,
            _ => {}
        }
    }

    pub fn open_list(&mut self) {
        self.screen = Screen::List;
        if self.scan == Scan::Idle {
            self.scan = Scan::Running { found: 0 };
            worker::spawn_scan(self.tx.clone(), self.scan_total, self.delay);
        }
    }

    fn on_list_key(&mut self, k: Key) {
        if BACK.matches(&k) {
            self.screen = Screen::Menu;
        } else if UP.matches(&k) {
            self.move_cursor(-1);
        } else if DOWN.matches(&k) {
            self.move_cursor(1);
        } else if TOGGLE.matches(&k) {
            self.toggle(self.view.cursor);
        } else if ALL.matches(&k) {
            self.toggle_all();
        } else if FILTER.matches(&k) {
            self.filtering = true;
        } else if APPLY.matches(&k) && !self.view.selected.is_empty() {
            let total = self.view.selected.len();
            self.apply = Apply::Running { done: 0, total };
            worker::spawn_apply(self.tx.clone(), total, self.delay);
        }
        let _ = binding::LIST_HELP;
    }

    pub fn move_cursor(&mut self, d: isize) {
        let max = self.view.filtered.len().saturating_sub(1) as isize;
        self.view.cursor = (self.view.cursor as isize + d).clamp(0, max) as usize;
        self.ensure_visible();
    }

    /// Keep the cursor inside the window of `viewport` rows.
    pub fn ensure_visible(&mut self) {
        let v = self.view.cursor;
        let h = self.viewport.max(1);
        if v < self.view.offset {
            self.view.offset = v;
        } else if v >= self.view.offset + h {
            self.view.offset = v + 1 - h;
        }
    }

    pub fn scroll(&mut self, d: isize) {
        let max = self.view.filtered.len().saturating_sub(self.viewport) as isize;
        self.view.offset = (self.view.offset as isize + d).clamp(0, max) as usize;
        // Cursor follows the window so keys continue from what the user sees.
        self.view.cursor = self.view.cursor.clamp(self.view.offset, self.view.offset + self.viewport.saturating_sub(1));
    }

    fn toggle(&mut self, filtered_idx: usize) {
        if let Some((row, _)) = self.view.filtered.get(filtered_idx) {
            let row = *row;
            if !self.view.selected.remove(&row) {
                self.view.selected.insert(row);
            }
        }
    }

    fn toggle_all(&mut self) {
        let all_on = self.view.filtered.iter().all(|(r, _)| self.view.selected.contains(r));
        for (r, _) in &self.view.filtered {
            if all_on {
                self.view.selected.remove(r);
            } else {
                self.view.selected.insert(*r);
            }
        }
    }

    pub fn on_mouse(&mut self, m: Mouse) {
        let pos = Position::new(m.column, m.row);
        let target = self.hits.at(pos);
        match m.kind {
            MouseKind::Moved => {
                self.hover = target;
                match target {
                    Some(Target::Row(i)) => self.view.cursor = i,
                    Some(Target::MenuItem(i)) => self.menu_cursor = i,
                    _ => {}
                }
            }
            MouseKind::Down(Button::Left) => self.on_click(target, pos),
            MouseKind::ScrollUp if over_list(target) => self.scroll(-3),
            MouseKind::ScrollDown if over_list(target) => self.scroll(3),
            _ => {}
        }
    }

    fn on_click(&mut self, target: Option<Target>, pos: Position) {
        match target {
            Some(Target::Dismiss) => self.show_help = false,
            Some(Target::HeaderBack) => self.screen = Screen::Menu,
            Some(Target::HeaderLink) => self.effects.push(Effect::OpenUrl("https://example.com".into())),
            Some(Target::MenuItem(i)) => self.activate_menu(i),
            Some(Target::Row(i)) => {
                self.view.cursor = i;
                self.toggle(i);
            }
            Some(Target::ScrollTrack) => {
                if let Some(r) = self.hits.rect_of(Target::ScrollTrack) {
                    let span = self.view.filtered.len().saturating_sub(self.viewport);
                    let ratio = (pos.y.saturating_sub(r.y)) as f64 / r.height.max(1) as f64;
                    self.view.offset = (ratio * span as f64).round() as usize;
                    self.scroll(0);
                }
            }
            _ => {}
        }
    }
}

fn over_list(t: Option<Target>) -> bool {
    matches!(t, Some(Target::Row(_) | Target::ListArea | Target::ScrollTrack))
}
