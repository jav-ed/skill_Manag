//! Key bindings that drive both dispatch and the help overlay (bubbles `key.Binding`).
use crate::input::{Code, Key, KeyKind, Mods};

pub struct Binding {
    pub keys: &'static [(Code, Mods)],
    pub key: &'static str,
    pub desc: &'static str,
}

impl Binding {
    pub fn matches(&self, ev: &Key) -> bool {
        // Kitty-protocol terminals can send Release events: ignore them.
        if ev.kind == KeyKind::Release {
            return false;
        }
        self.keys.iter().any(|(c, m)| *c == ev.code && *m == ev.mods)
    }
}

const N: Mods = Mods::NONE;
pub const UP: Binding = Binding { keys: &[(Code::Up, N), (Code::Char('k'), N)], key: "↑/k", desc: "up" };
pub const DOWN: Binding = Binding { keys: &[(Code::Down, N), (Code::Char('j'), N)], key: "↓/j", desc: "down" };
pub const TOGGLE: Binding = Binding { keys: &[(Code::Char(' '), N)], key: "space", desc: "toggle" };
pub const ALL: Binding = Binding { keys: &[(Code::Char('a'), N)], key: "a", desc: "all" };
pub const FILTER: Binding = Binding { keys: &[(Code::Char('/'), N)], key: "/", desc: "filter" };
pub const APPLY: Binding = Binding { keys: &[(Code::Enter, N)], key: "enter", desc: "apply" };
pub const HELP: Binding = Binding { keys: &[(Code::Char('?'), N), (Code::Char('?'), Mods::SHIFT)], key: "?", desc: "help" };
pub const BACK: Binding = Binding {
    keys: &[(Code::Char('q'), N), (Code::Left, Mods::ALT), (Code::Esc, N)],
    key: "q/alt+←",
    desc: "back",
};
pub const QUIT: Binding = Binding { keys: &[(Code::Char('c'), Mods::CTRL)], key: "ctrl+c", desc: "quit" };

pub const LIST_HELP: &[&Binding] = &[&UP, &DOWN, &TOGGLE, &ALL, &FILTER, &APPLY, &HELP, &BACK];
